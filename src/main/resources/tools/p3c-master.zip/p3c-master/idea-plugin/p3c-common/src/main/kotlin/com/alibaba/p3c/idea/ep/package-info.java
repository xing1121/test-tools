/**
 * extension point
 *
 * @author caikang
 * @date 2017/06/19
 */
package com.alibaba.p3c.idea.ep;