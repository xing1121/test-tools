window->preferences->java->code style-> Code Templates ------ import codeTemplates.xml
file->import->general->preferences ------ import marsPrefrence.epf